Hi thank you for downloading this pack.

You may use this in any project.

However please do not resell this product in any other graphical pack.